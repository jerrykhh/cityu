#include<iostream>
#include<cmath> 
using namespace std;

int main(){
    int t,k,m;
    cin>>t;
    while(t--){
        cin>>k;
        for(int i=0;i<pow(2,k);i++){
            
        }
        cin>>m;
        for(m--){
            //flip
        }
    }
}