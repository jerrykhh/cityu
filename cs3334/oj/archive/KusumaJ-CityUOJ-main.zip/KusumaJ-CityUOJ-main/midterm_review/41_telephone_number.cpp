#include<iostream>
#include<string.h>
using namespace std;

class node{
    public:
    int data;
    node* next;
};

class Stack{
    int* arr[1000000];

};

class Dial{

    bool addEle(string a){

    }
};

int main(){
    int n;
    cin>>n;
    string s;
    for(int i=0;i<n;i++){
        getline(cin,s);

        cout<<s;
    }
}