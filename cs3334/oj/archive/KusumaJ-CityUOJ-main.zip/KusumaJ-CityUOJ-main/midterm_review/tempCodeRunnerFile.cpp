*(B+indexB)){
        //     if(indexB>=m) break;
        //     count++;
        //     indexB++;
        // }