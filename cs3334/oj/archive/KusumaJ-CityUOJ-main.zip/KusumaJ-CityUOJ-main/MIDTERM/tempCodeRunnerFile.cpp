st->data = n;
            // first->next = last;
            // cou