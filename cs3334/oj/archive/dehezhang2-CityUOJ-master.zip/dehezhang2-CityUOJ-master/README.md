# CityU OJ Codes

This repo contains my solutions to the course CS3334 (Data structure) and CS3391 (Advanced programming). The primary language to solve the challenges is C++. And please find the corresponding problem discription in [CityU online judge website](https://www.cs.cityu.edu.hk/~acm/). 

The cheatsheet of the course CS3334 is also provided as a [PDF](./cs3334.pdf) file. The CS3391 cheatsheet will also be provided in the future. 